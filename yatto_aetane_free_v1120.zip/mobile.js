// v11.1: explicit update consent, offline indicator and resilient registration.
(()=>{'use strict';
const status=document.getElementById('connection-status');
function refresh(){if(!status)return;status.hidden=navigator.onLine;status.textContent=navigator.onLine?'':'オフラインです。保存済みの機能を利用できます。';}
window.addEventListener('online',refresh);window.addEventListener('offline',refresh);refresh();
if(!('serviceWorker'in navigator))return;
let acceptedUpdate=false;let dismissedWorker=null;
navigator.serviceWorker.addEventListener('controllerchange',()=>{if(acceptedUpdate)location.reload();});
function showUpdate(reg){const worker=reg.waiting;if(!worker||!navigator.serviceWorker.controller||worker===dismissedWorker)return;
if(document.getElementById('update-app'))return;
const bar=document.createElement('div');bar.id='update-app';bar.setAttribute('role','status');bar.setAttribute('aria-live','polite');
const msg=document.createElement('span');msg.textContent='新しいバージョンを利用できます。 ';
const button=document.createElement('button');button.type='button';button.textContent='更新する';
button.addEventListener('click',()=>{acceptedUpdate=true;button.disabled=true;button.textContent='更新中…';worker.postMessage({type:'SKIP_WAITING'});});
const later=document.createElement('button');later.type='button';later.textContent='あとで';later.addEventListener('click',()=>{dismissedWorker=worker;bar.remove();});
bar.append(msg,button,later);document.body.append(bar);}
window.addEventListener('load',async()=>{try{const reg=await navigator.serviceWorker.ready;showUpdate(reg);
reg.addEventListener('updatefound',()=>{const worker=reg.installing;if(!worker)return;worker.addEventListener('statechange',()=>{if(worker.state==='installed')showUpdate(reg);});});
reg.update().catch(err=>console.warn('更新確認失敗',err));
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)reg.update().catch(()=>{});});
}catch(err){console.warn('更新通知を開始できません',err);}});
})();

// v11.1: optional install prompt. Never force an install or interrupt conversations.
(()=>{let deferredPrompt=null;window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();deferredPrompt=event;if(document.getElementById('install-app')||window.matchMedia('(display-mode: standalone)').matches)return;const bar=document.createElement('div');bar.id='install-app';bar.setAttribute('role','status');const label=document.createElement('span');label.textContent='ホーム画面にアプリを追加できます。 ';const install=document.createElement('button');install.type='button';install.textContent='追加する';const later=document.createElement('button');later.type='button';later.textContent='あとで';function dismiss(){bar.remove();}install.addEventListener('click',async()=>{if(!deferredPrompt)return;const prompt=deferredPrompt;deferredPrompt=null;dismiss();try{await prompt.prompt();await prompt.userChoice;}catch(err){console.warn('インストール操作を完了できません',err);}});later.addEventListener('click',()=>{deferredPrompt=null;dismiss();});bar.append(label,install,later);document.body.append(bar);});window.addEventListener('appinstalled',()=>{deferredPrompt=null;document.getElementById('install-app')?.remove();});})();
