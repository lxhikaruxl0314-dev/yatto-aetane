import hashlib,json,pathlib,subprocess,datetime
p=pathlib.Path(__file__).resolve().parent
js=(p/'app.js').read_text()
import re
hashes=dict(re.findall(r"'(YUI-KOMOREBI-001|AYANO-REAL-001|SAKURA-ANIME-001)':'([0-9a-f]{64})'",js))
images={'YUI-KOMOREBI-001':'2054.jpg','AYANO-REAL-001':'2028.png','SAKURA-ANIME-001':'2008.png'}
results={}
for id,filename in images.items():
 actual=hashlib.sha256((p/'assets'/filename).read_bytes()).hexdigest()
 results[id]={'image':filename,'sha256':actual,'approved_match':actual==hashes.get(id)}
checks={}
for f in ['app.js','smoke_test.js','suggestion_test.js']:
 r=subprocess.run(['node','--check',str(p/f)],capture_output=True,text=True)
 checks[f]={'passed':r.returncode==0,'detail':r.stderr.strip()}
for f in ['smoke_test.js','suggestion_test.js']:
 r=subprocess.run(['node',str(p/f)],cwd=p,capture_output=True,text=True)
 checks[f+'_run']={'passed':r.returncode==0,'output':(r.stdout+'\n'+r.stderr).strip()[-1200:]}
report={'version':'9.4','type':'offline-browser-prototype','image_checks':results,'automated_checks':checks,'browser_ui_test':'not_tested','android_device_test':'not_tested','generative_ai':'not_implemented','all_offline_checks_passed':all(v['approved_match'] for v in results.values()) and all(v['passed'] for v in checks.values())}
(p/'test_report_v940.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
