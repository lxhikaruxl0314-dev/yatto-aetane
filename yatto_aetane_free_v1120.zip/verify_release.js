// Offline release audit. Requires Node.js; no npm dependencies.
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert'),cp=require('child_process');
const root=__dirname, results={};
function check(name,fn){try{fn();results[name]='PASS';}catch(e){results[name]='FAIL: '+e.message;process.exitCode=1;}}
check('requiredFiles',()=>{for(const f of ['index.html','app.js','mobile.js','style.css','sw.js','manifest.webmanifest','diagnostics.html','icons/icon-192.png','icons/icon-512.png'])assert(fs.existsSync(path.join(root,f)),f);});
check('approvedImages',()=>{const data=JSON.parse(fs.readFileSync(path.join(root,'approved_assets_v930.json')));for(const c of Object.values(data.characters)){const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,c.filename))).digest('hex');assert.strictEqual(actual,c.sha256,c.filename);}});
check('manifest',()=>{const m=JSON.parse(fs.readFileSync(path.join(root,'manifest.webmanifest')));assert.strictEqual(m.display,'standalone');for(const i of m.icons)assert(fs.existsSync(path.join(root,i.src)),i.src);});
check('javascriptSyntax',()=>{for(const f of ['app.js','mobile.js','sw.js','smoke_test.js','suggestion_test.js'])cp.execFileSync(process.execPath,['--check',path.join(root,f)],{stdio:'pipe'});});
check('offlineAssets',()=>{const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');assert(sw.includes('v111-static-1'));for(const f of ['index.html','app.js','mobile.js','style.css','manifest.webmanifest','assets/2054.jpg','assets/2028.png','assets/2008.png'])assert(sw.includes('./'+f),f);});
check('cacheSafety',()=>{const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');assert(sw.includes("request.method !== 'GET'"),'non-GET interception');assert(sw.includes('url.origin !== SCOPE.origin'),'cross origin interception');assert(!sw.includes("cache.put(request"),'navigation must not be cached');});
check('smokeTest',()=>cp.execFileSync(process.execPath,[path.join(root,'smoke_test.js')],{stdio:'pipe'}));
check('suggestionTest',()=>cp.execFileSync(process.execPath,[path.join(root,'suggestion_test.js')],{stdio:'pipe'}));
check('backupVersion',()=>{const app=fs.readFileSync(path.join(root,'app.js'),'utf8');assert(app.includes("version:'11.1'"));assert(app.includes('yatto-aetane-v111-backup.json'));assert(app.includes('現在の保存データをバックアップで置き換えますか？'));});
check('githubPagesWorkflow',()=>{const w=fs.readFileSync(path.join(root,'.github/workflows/pages.yml'),'utf8');assert(w.includes('actions/deploy-pages@v4'));assert(w.includes('node verify_release.js'));});
console.log(JSON.stringify({version:'11.1',results},null,2));
