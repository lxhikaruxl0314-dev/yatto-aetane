# やっと会えたね v11.2 — Android公開を始める

このZIPは **GitHubリポジトリのルートにそのまま展開できる構成**です。以前のZIPと違い、アプリファイルを入れた余分な親フォルダがありません。

## GitHub Pages 公開
1. GitHubで新規リポジトリを作る。公開リポジトリにアップロードする画像・ソースの公開権限を確認する。
2. ZIPを解凍して **中身をすべて** リポジトリの `main` ブランチのルートにアップロードする。隠しフォルダ `.github` も必須。
3. Settings → Pages → Build and deployment → Source → **GitHub Actions** を選択する。
4. Actions → Publish PWA to GitHub Pages が成功したら、Settings → Pages の公開HTTPS URLを開く。
5. AndroidのChromeでURLを開き、メニューから「アプリをインストール」または「ホーム画面に追加」を選ぶ。
6. `ANDROID_TEST_CHECKLIST.md` に沿って動作確認する。

## 重要
- ZIPをダウンロードしただけではAndroidにインストールできません。公開と端末操作が必要です。
- GitHubへのアップロードや実機操作は未実施。APKは未作成。生成AI自由会話は未実装。
- 画像を含む公開ファイルは第三者が閲覧できる可能性があります。
- 保存データは端末依存。更新やサイトデータ削除前にバックアップしてください。
