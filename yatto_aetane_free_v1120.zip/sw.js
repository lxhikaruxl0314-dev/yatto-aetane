// v11.1: only cache app shell; prevent arbitrary HTML pages being cached.
const CACHE = 'yatto-aetane-v111-static-1';
const PREFIX = 'yatto-aetane-';
const SCOPE = new URL(self.registration.scope);
const ASSETS = ['./', './index.html', './style.css', './app.js', './mobile.js', './manifest.webmanifest', './assets/2054.jpg', './assets/2028.png', './assets/2008.png', './icons/icon-192.png', './icons/icon-512.png', './diagnostics.html'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS))));
self.addEventListener('activate', event => event.waitUntil((async () => {
  const keys = await caches.keys();
  await Promise.all(keys.filter(key => key.startsWith(PREFIX) && key !== CACHE).map(key => caches.delete(key)));
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== SCOPE.origin || !url.pathname.startsWith(SCOPE.pathname)) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok) return response;
        if (response.status !== 503 && response.status !== 504) return response;
      } catch (_) { /* offline */ }
      return (await caches.match(new URL('./index.html', SCOPE).href)) || Response.error();
    })());
    return;
  }
  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    return fetch(request);
  })());
});
self.addEventListener('message', event => { if (event.data?.type === 'SKIP_WAITING') self.skipWaiting(); });
