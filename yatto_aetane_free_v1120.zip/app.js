(()=>{'use strict';
const KEY='yatto-aetane-demo-v69'; // v7.6: preserve existing local saves
const chars=[{id:'YUI-KOMOREBI-001',name:'結衣',world:'リアルワールド',symbol:'🌿',hello:'はじめまして。結衣です。今日は会えてうれしいな。',date:'木漏れ日のカフェで、結衣とゆっくり過ごした。'},{id:'AYANO-REAL-001',name:'彩乃',world:'リアルワールド',symbol:'🌷',hello:'こんにちは、彩乃です！ 会えてうれしいよ。',date:'街角のカフェで、彩乃と楽しくおしゃべりした。'},{id:'SAKURA-ANIME-001',name:'さくら',world:'アニメワールド',symbol:'🌸',hello:'やっと会えたね！ さくらだよ。よろしくね！',date:'桜の並木道で、さくらと特別な時間を過ごした。'}];
const expectedHashes={'YUI-KOMOREBI-001':'992868cc403e30678061a851a28eec8ae90636334434673472ad8221d451d37b','AYANO-REAL-001':'aad20623d106c384f089a64b9dd01736f0b585706b174033bcc2885906c8a7da','SAKURA-ANIME-001':'7b1b66fef2cc6a23e053b6f544ee079cc1fa9fefeb644b02dd59960cbef0d538'};
const imageUrls={};
const bundledProfiles={'YUI-KOMOREBI-001':'assets/2054.jpg','AYANO-REAL-001':'assets/2028.png','SAKURA-ANIME-001':'assets/2008.png'};
const profileDetails={'YUI-KOMOREBI-001':{age:'24歳',job:'カフェ「こもれび」パティシエ',personality:'明るく親しみやすい。少し頑固だけど、自分の意思を大切にする。',hobbies:'カフェ巡り・写真・水族館・読書',dream:'自分のお菓子屋さんを開くこと。'},'AYANO-REAL-001':{age:'23歳',job:'カフェ店員・大学生',personality:'明るくて甘えん坊。一途で素直、ちょっぴり照れ屋。',hobbies:'カフェ巡り・スイーツ・映画・旅行・猫',dream:'一緒にたくさんの思い出をつくること。'},'SAKURA-ANIME-001':{age:'25歳',job:'大学院生・研究生（生命科学系）',personality:'好奇心が強く努力家。優しくて素直、少し照れ屋。',hobbies:'カフェ巡り・読書・映画・研究の合間のスイーツ',dream:'研究で人の役に立つ発見をすること。'}};
const avatar=x=>imageUrls[x.id]?`<img class="portrait" src="${imageUrls[x.id]}" alt="${x.name}の承認済み画像">`:`<img class="portrait" src="${bundledProfiles[x.id]}" alt="${x.name}の提供プロフィールカード">`; 
const defaults=()=>({approved:false,consent:false,name:'',selected:null,stage:{},affinity:{},messages:{},memories:[],daily:{day:'',count:0},conversationContext:{},personalMemory:{},datePlans:{},screen:'home'});
let state;try{state={...defaults(),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{state=defaults()}
let screen='home';const app=document.getElementById('app');const today=()=>{const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')};const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(state))}catch{alert('保存に失敗しました。ブラウザの空き容量を確認してください。')}};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const c=()=>chars.find(x=>x.id===state.selected);const affinity=()=>state.affinity[state.selected]||0;const stage=()=>state.stage[state.selected]||0;
const preferredPlace=()=>{const entries=((state.personalMemory||{})[state.selected]||[]);const values=entries.filter(e=>e.type==='好きなもの'||e.type==='約束').map(e=>String(e.value||'')).reverse();for(const v of values){if(/クラゲ|水族館|海/.test(v))return {place:'水族館',detail:'クラゲを眺めながら過ごす',source:v};if(/猫|ねこ/.test(v))return {place:'猫カフェ',detail:'猫たちとゆっくり過ごす',source:v};if(/ケーキ|スイーツ|お菓子|カフェ/.test(v))return {place:'カフェ',detail:'お気に入りのスイーツを楽しむ',source:v};if(/映画/.test(v))return {place:'映画館',detail:'一緒に映画を楽しむ',source:v};}return null};
const storyEnding=(x,choice)=>{const p=preferredPlace();if(!p)return choice==='kind'?x.date:`${x.name}と行きたい場所を相談して、次の約束をした。`;return choice==='kind'?`${x.name}と${p.place}へ。${p.detail}、ふたりの思い出が増えた。`:`${x.name}と${p.place}へ行く約束をした。${p.detail}のが楽しみだ。`};
const addMemory=(text)=>{if(state.memories.length>=20)return;state.memories.push({id:Date.now()+Math.random(),char:state.selected,text,at:new Date().toISOString()})};
const planFor=()=>((state.datePlans||{})[state.selected]||null);
const nav=()=>'<nav class="nav">'+[['home','🏠 ホーム'],['characters','💗 出会い'],['story','📖 物語'],['chat','💬 会話'],['memories','✨ 思い出'],['settings','⚙️ 設定']].map(([id,label])=>`<button class="${screen===id?'active':''}" data-go="${id}">${label}</button>`).join('')+'</nav>';
const header=(title,desc='')=>`<header class="hero"><div class="sub" style="color:#e8d6ef">無料体験版 v10.0 · オフラインデモ</div><h1>${title}</h1><p>${desc}</p></header>`;
function render(){let body='';if(screen==='home'){body=header('やっと会えたね','あなたと、もう一度出会う物語。')+`<div class="content"><div class="card"><h2>ようこそ${state.name?'、'+esc(state.name)+'さん':''} 🌸</h2><p>3人との出会いから、会話、デートまで楽しめる体験版です。</p><p class="sub">これはAI未接続のシナリオ体験版です。提供されたプロフィールカードを表示しています。3人のプロフィールカードは正式承認済みです。</p><button class="button" data-go="${state.approved?'characters':'register'}">${state.approved?'キャラクターを選ぶ':'無料で始める'}</button></div><div class="card"><h3>体験できること</h3><p>🌷 3人のキャラクター<br>📖 選択肢で変わるストーリー<br>💬 1日30通の体験用会話<br>✨ 親密度と20件までの思い出</p></div><button class="button secondary" data-go="premium">プレミアム版のご案内</button></div>`}
else if(screen==='register'){body=header('体験登録','利用規約とプライバシーを確認して開始')+`<main class="content"><div class="card"><label>呼ばれたい名前<input id="username" class="field" maxlength="30" value="${esc(state.name)}" placeholder="ニックネーム"></label><div class="notice">この試作版では、名前・会話・進行状況をこの端末のブラウザ内に保存します。外部送信はしません。端末を共有する場合はご注意ください。キャラクターは架空のAIキャラクターで、会話は定型シナリオです。</div><p><label><input id="consent" type="checkbox" ${state.consent?'checked':''}> 上記の説明と体験版利用条件に同意します</label></p><button class="button" data-action="approve">登録して始める</button></div></main>`}
else if(screen==='characters'){body=header('出会いを選ぶ','今日は誰とお話しする？')+`<main class="content">${chars.map(x=>`<div class="card"><div class="person"><div class="avatar">${avatar(x)}</div><div><h3>${x.name}</h3><div class="sub">${x.world} · ${profileDetails[x.id].age}</div><div class="sub">${imageUrls[x.id]?'SHA-256検証済み画像':'正式承認済みプロフィールカード'}</div></div></div><p class="character-intro">${x.hello}</p><div class="profile-facts"><p><strong>お仕事</strong> ${profileDetails[x.id].job}</p><p><strong>性格</strong> ${profileDetails[x.id].personality}</p><p><strong>趣味</strong> ${profileDetails[x.id].hobbies}</p><p><strong>夢</strong> ${profileDetails[x.id].dream}</p></div><details class="profile-expand"><summary>元のプロフィールカードを見る</summary><img class="profile-card" src="${bundledProfiles[x.id]}" alt="${x.name}のプロフィール詳細"></details><button class="button" data-select="${x.id}">${state.selected===x.id?'この人と続ける':'この人に会う'}</button></div>`).join('')}</main>`}
else if(screen==='story'){let x=c();body=header('ふたりの物語',x?x.name+'とのストーリー':'まず相手を選んでね')+`<main class="content">${!x?'<button class="button" data-go="characters">相手を選ぶ</button>':`<div class="card"><div class="story-portrait">${avatar(x)}</div><div class="row"><h3>${x.symbol} ${x.name}</h3><span class="pill">第${Math.min(stage()+1,5)}章 / 5</span></div><p class="story">${[`${x.name}と初めて出会った。少し緊張しているみたい。`,`${x.name}があなたのことを知りたがっている。`,`${x.name}との何気ない会話が心地いい。`,`${x.name}と前よりも仲良くなれた気がする。`,`${x.name}から、デートのお誘いが届いた。${preferredPlace()?' 前に話した「'+esc(preferredPlace().source)+'」を覚えていてくれたみたい。':''}`][Math.min(stage(),4)]}</p>${stage()<5?`<button class="button" data-choice="kind">${['笑顔で挨拶する','自分のことを話す','最近の出来事を話す','また会いたいと伝える',(preferredPlace()?'一緒に'+preferredPlace().place+'へ行く':'一緒にデートする')][stage()]}</button><button class="button secondary" data-choice="gentle">${['少し照れながら会釈する','相手の話を聞く','好きなことを質問する','ゆっくり距離を縮める',(preferredPlace()?preferredPlace().place+'へのお出かけを相談する':'行きたい場所を相談する')][stage()]}</button>`:'<p>無料体験ストーリーはここまで。ふたりの思い出を振り返ってね。</p><button class="button" data-go="memories">思い出を見る</button>'}</div>`}</main>`}
else if(screen==='chat'){let x=c(),d=state.daily.day===today()?state.daily.count:0,history=x?(state.messages[x.id]||[]):[];body=header('おしゃべり',x?x.name+'との会話':'まず相手を選んでね')+`<main class="content">${!x?'<button class="button" data-go="characters">相手を選ぶ</button>':`<div class="notice">話題と明示的に伝えた好み・約束を端末内で記憶する定型応答です（生成AIではありません）。生成AIとの自由会話ではありません。残り ${30-d} / 30 メッセージ（端末の日付で更新）</div><div class="notice">💭 覚えたこと：${esc(((state.personalMemory||{})[x.id]||[]).slice(-3).map(e=>e.type+'：'+e.value).join(' ／ ')||'まだありません')}<br><small>「クラゲが好き」「今度水族館に行こう」などと話してみてね。「覚えてる？」で確認できます。デート後は「前のデート覚えてる？」「次のデートはどこ？」と聞いてみてね。提案には「行きたい」「別の場所がいい」「やめておく」と答えられます。</small></div>${planFor()?`<div class="notice">📅 ${esc(planFor().place)}：${planFor().status==='accepted'?'行く約束（日時未定）':'提案中'} <button class="button secondary" data-action="cancel-date">予定を取り消す</button></div>`:''}<div class="chat-companion">${avatar(x)}<span>${esc(x.name)}とおしゃべり</span></div><div class="bubble">${esc(x.hello)}</div>${history.map(m=>`<div class="bubble ${m.role==='user'?'me':''}">${esc(m.text)}</div>`).join('')}<form id="chat-form"><input class="field" name="message" maxlength="300" placeholder="メッセージを入力" required ${d>=30?'disabled':''}><button class="button" ${d>=30?'disabled':''}>送信</button></form>`}</main>`}
else if(screen==='memories'){let x=c();body=header('思い出アルバム','大切な瞬間を残そう')+`<main class="content"><div class="card"><h3>親密度 ${x?'— '+x.name:''}</h3><div class="progress"><div style="width:${x?affinity():0}%"></div></div><p>${x?affinity():0} / 100</p><p class="sub">思い出 ${state.memories.length} / 20 件</p>${x&&preferredPlace()?`<p class="sub">💗 覚えた好みからのデート候補：${esc(preferredPlace().place)}</p>`:''}</div>${state.memories.length?state.memories.slice().reverse().map(m=>`<div class="card"><div class="sub">${esc(chars.find(x=>x.id===m.char)?.name||'キャラクター')} · ${esc(new Date(m.at).toLocaleDateString('ja-JP'))}</div><p>${esc(m.text)}</p></div>`).join(''):'<div class="empty">まだ思い出はありません。物語を始めよう。</div>'}</main>`}
else if(screen==='settings'){body=header('設定','データと利用状況')+`<main class="content"><div class="card"><h3>承認済み画像の読み込み</h3><p class="sub">画像ファイルのSHA-256が現在の正式承認記録と一致した場合のみ表示します。画像はこのブラウザのIndexedDBに保存します。</p>${chars.map(x=>`<label class="image-label">${x.name}：<input type="file" accept="image/*" data-image-id="${x.id}"></label>`).join('')}<p id="image-status" class="sub"></p></div><div class="card"><p>登録：${state.approved?'体験登録済み':'未登録'}</p><p>保存場所：このブラウザのローカルストレージ</p><button class="button secondary" data-action="export">データをJSONで書き出す</button><label class="image-label">バックアップを読み込む<input type="file" accept="application/json,.json" data-import-backup></label><p id="backup-status" class="sub"></p><button class="button secondary" data-action="clear-chat">会話履歴を削除</button><button class="button secondary" data-action="reset">すべての体験データを削除</button></div><div class="notice">バックアップ復元では思い出・親密度・約束を引き継ぎます。本日の送信回数は復元によって減りません。</div><div class="notice">バックアップには会話やニックネームなどの個人データが含まれます。信頼できる場所で保管してください。画像はバックアップに含まれません。</div><div class="notice">機種変更やブラウザデータ削除では記録が失われることがあります。有料版への自動移行・同期は未実装です。</div></main>`}
else if(screen==='premium'){body=header('プレミアム版','今後の開発予定')+`<main class="content"><div class="card"><h2>もっと深い物語へ</h2><p>特別ストーリー、衣装、長期記憶などを将来検討しています。</p><p class="sub">現在は販売・課金・購入ボタンはありません。価格も未確定です。</p><button class="button secondary" data-go="home">ホームへ戻る</button></div></main>`}
app.innerHTML=`<div class="shell">${body}<div class="footer">やっと会えたね · 無料体験版 v10.0</div>${nav()}</div>`;}
function go(s){if(!state.approved&&!['home','register','premium'].includes(s))s='register';screen=s;render();window.scrollTo(0,0)}
function start(id){if(!state.approved)return go('register');state.selected=id;save();go('story')}
function storyChoice(choice){if(!c()||stage()>=5)return;let n=stage();state.stage[state.selected]=n+1;state.affinity[state.selected]=Math.min(100,affinity()+(choice==='kind'?12:9));if(n===0)addMemory('初めて出会った日');if(n===4)addMemory(storyEnding(c(),choice));save();render()}
function demoReply(x,message,previousTopic=''){
 const m=message.normalize('NFKC').toLowerCase();
 const patterns=[[/ありがとう|ありがと|感謝/, 'thanks'],[/悲しい|寂しい|さみしい|つらい|疲れ|不安/, 'comfort'],[/水族館|クラゲ|海/, 'aquarium'],[/猫|ねこ|にゃん/, 'cat'],[/ケーキ|お菓子|スイーツ|甘い/, 'sweets'],[/研究|勉強|大学|実験/, 'study'],[/デート|会いたい|お出かけ|一緒に/, 'date'],[/おはよう|こんにちは|こんばんは|やっほ/, 'greeting'],[/好き|大好き/, 'affection']];
 const detected=(patterns.find(([re])=>re.test(m))||[])[1]||'other';
 const followUp=/^(うん|そう|それ|詳しく|もっと|いいね|お願い|ぜひ|はい|教えて|行きたい)[！!。\s]*$/.test(message.trim());
 const topic=detected==='other'&&followUp&&previousTopic?previousTopic:detected;
 const lines={
 'YUI-KOMOREBI-001':{thanks:'こちらこそ、ありがとう。温かい気持ちになったよ。',comfort:'そうだったんだね。無理しないで、ここで少し休んでいこう？',aquarium:'水族館いいね！ クラゲを眺めながらのんびりしたいな。',cat:'猫って見ているだけで癒やされるよね。',sweets:'お菓子の話なら任せて。今度、焼きたてのケーキを食べてほしいな。',study:'頑張っているんだね。甘いものを食べながらひと休みしよう。',date:'うれしいな。カフェでゆっくりお話しできたらいいね。',greeting:'こんにちは！ 今日はどんな一日だった？',affection:'ふふ、照れちゃう。ゆっくり仲良くなれたらうれしいな。',other:'そうなんだね。もう少し詳しく聞かせてくれる？'},
 'AYANO-REAL-001':{thanks:'えへへ、こちらこそありがとう！',comfort:'そっか……。話したくなったら、いつでも聞くよ。',aquarium:'水族館！ 楽しそう。帰りにスイーツも食べたいな。',cat:'猫ちゃん大好き！ どんな子が好き？',sweets:'スイーツの話？ やった！ 一緒にカフェ巡りしたいな。',study:'勉強おつかれさま！ 頑張ったごほうびに甘いものだね。',date:'ほんと？ じゃあ一緒にお出かけする場所を考えよう！',greeting:'やっほー！ 会えてうれしいよ。',affection:'えっ、うれしい……！ ちょっと照れちゃった。',other:'うんうん！ それでどうなったの？'},
 'SAKURA-ANIME-001':{thanks:'ありがとう！ 私もすごくうれしいよ。',comfort:'大変だったね。焦らず、少しずつ話してくれていいからね。',aquarium:'クラゲって不思議だよね。生き物の仕組みを考えるとわくわくする！',cat:'猫のしぐさって面白いよね。つい観察しちゃう。',sweets:'研究の合間のスイーツは最高！ おすすめを教えて？',study:'研究の話？ うれしい！ どんなことに興味があるの？',date:'一緒に行けたら楽しそう！ 新しい発見がありそうだね。',greeting:'こんにちは！ 今日も会えてうれしいな。',affection:'わっ……ありがとう。これからもっとお互いを知りたいな。',other:'面白いね！ もっと聞いてみたいな。'}};
 return lines[x.id][topic];
}
// v7.5: local, per-character opt-in-style phrase detection; no network or generative AI.
function rememberPhrase(id,message){
 const memory=state.personalMemory||(state.personalMemory={});
 const entries=memory[id]||(memory[id]=[]);
 const m=message.normalize('NFKC').trim();
 const rules=[
  {type:'好きなもの',re:/(?:私は|僕は|ぼくは|俺は)?(.{1,24}?)(?:が好き|を好き)/},
  {type:'苦手なもの',re:/(?:私は|僕は|ぼくは|俺は)?(.{1,24}?)(?:が苦手|は苦手)/},
  {type:'約束',re:/(?:今度|いつか|次は)(.{2,36}?)(?:しよう|行こう|しようね|行きたい)/}
 ];
 for(const rule of rules){const hit=m.match(rule.re);if(!hit)continue;
  let value=hit[1].replace(/^(?:、|。|ね|えっと|ちなみに|私は|僕は|ぼくは|俺は|そして|でも|やっぱり|特に|本当に|すごく|とても|ちょっと|今度)/,'').trim();
  if(value.length<1||value.length>36)continue;
  if(!entries.some(e=>e.type===rule.type&&e.value===value)){
   entries.push({type:rule.type,value,at:new Date().toISOString()});
   if(entries.length>12)entries.shift();
  }
  return {type:rule.type,value};
 }
 return null;
}
function memoryReply(id,message){
 if(!/覚えてる|覚えている|何が好き|何が苦手|約束|私のこと|僕のこと/.test(message))return '';
 const entries=(state.personalMemory||{})[id]||[];
 if(!entries.length)return 'まだ覚えている好みや約束はないよ。好きなものや約束を教えてくれる？';
 const filter=/約束/.test(message)?entries.filter(e=>e.type==='約束'):/苦手/.test(message)?entries.filter(e=>e.type==='苦手'):/好き/.test(message)?entries.filter(e=>e.type==='好きなもの'):entries;
 return filter.length?'覚えているよ。'+filter.slice(-3).map(e=>e.type+'は「'+e.value+'」').join('、')+'だよ。':'そのことはまだ覚えていないみたい。教えてくれる？';
}
function dateRecall(id,message){
 if(!/前に|この前|思い出|デート|一緒に行った|覚えてる|振り返/.test(message))return '';
 const dates=(state.memories||[]).filter(m=>m.char===id && /デート|へ。|へ行く約束|とゆっくり過ごした|と楽しくおしゃべりした|特別な時間/.test(m.text));
 if(!dates.length)return /思い出|前に.*行った|一緒に行った|デート.*覚えてる/.test(message)?'まだ一緒に行ったデートの記録はないみたい。これから思い出を作ろうね。':'';
 const latest=dates[dates.length-1];
 return '覚えているよ。'+latest.text+' また一緒に楽しい時間を過ごしたいな。';
}
function nextDateSuggestion(id){
 const records=(state.memories||[]).filter(m=>m.char===id && /デート|へ。|へ行く約束|とゆっくり過ごした|と楽しくおしゃべりした|特別な時間/.test(m.text));
 const last=records[records.length-1];const entries=((state.personalMemory||{})[id]||[]).filter(e=>e.type==='好きなもの'||e.type==='約束');
 const prefs=[...entries].reverse().map(e=>String(e.value||''));
 const destinations=[['水族館',/クラゲ|水族館|海/],['猫カフェ',/猫|ねこ/],['スイーツカフェ',/ケーキ|スイーツ|お菓子|カフェ/],['映画館',/映画/]];
 const candidates=destinations.filter(([place,re])=>prefs.some(v=>re.test(v)));
 const next=candidates.find(([place])=>!last||!last.text.includes(place))||candidates[0];
 if(next)return {place:next[0],reason:last?'前の思い出も大切にしながら、':'好きだと教えてくれたことを覚えているから、'};
 return {place:last?'公園でのんびりお散歩':'カフェでおしゃべり',reason:last?'この前の思い出を振り返りながら、':'まずはゆっくりお話しできるように、'};
}
function suggestionReply(id,message){
 if(!/次のデート|次はどこ|次どこ|おすすめのデート|お出かけ提案|どこに行きたい/.test(message))return '';
 const x=chars.find(c=>c.id===id);const idea=nextDateSuggestion(id);
 return `${x.name}「${idea.reason}今度は${idea.place}に行ってみない？ もちろん、あなたの行きたい場所も聞きたいな。」`;
}
function datePlanReply(id,message){
 const normalized=message.normalize('NFKC').trim();const plans=state.datePlans||(state.datePlans={});const plan=plans[id];
 if(plan&&/^(行きたい|行こう|いいね|ぜひ|お願い|はい|うん)[！!。\s]*$/.test(normalized)){
  plan.status='accepted';return `うれしい！ ${plan.place}に一緒に行く約束だね。日時はまだ決まっていないから、都合のいいときに相談しよう。`;
 }
 if(plan&&/別の場所|ほかの場所|他の場所|変更したい/.test(normalized)){
  const choices=['水族館','猫カフェ','映画館','スイーツカフェ','公園','カフェ'];const place=choices.find(p=>p!==plan.place)||'公園';plans[id]={place,status:'proposed'};return `もちろん！ じゃあ${place}はどうかな？ 無理に決めなくていいよ。`;
 }
 if(plan&&/やめておく|キャンセル|断る|行かない/.test(normalized)){delete plans[id];return 'わかったよ。また気が向いたら、一緒に考えようね。';}
 if(/次のデート|次はどこ|次どこ|おすすめのデート|お出かけ提案|どこに行きたい/.test(normalized)){
  const idea=nextDateSuggestion(id);plans[id]={place:idea.place,status:'proposed'};return `${idea.reason}今度は${idea.place}に行ってみない？ 「行きたい」「別の場所がいい」「やめておく」から選んでね。`;
 }
 return '';
}
function send(message){let x=c();if(!x||!state.approved)return;let t=today();if(state.daily.day!==t)state.daily={day:t,count:0};if(state.daily.count>=30)return;let arr=state.messages[x.id]||(state.messages[x.id]=[]);const context=state.conversationContext||(state.conversationContext={});const prior=context[x.id]||'';const recalled=datePlanReply(x.id,message)||dateRecall(x.id,message)||memoryReply(x.id,message);const remembered=rememberPhrase(x.id,message);const reply=recalled||(remembered?'教えてくれてありがとう。「'+remembered.value+'」のこと、覚えておくね。':demoReply(x,message,prior));const match=message.normalize('NFKC').toLowerCase().match(/水族館|クラゲ|海|猫|ねこ|にゃん|ケーキ|お菓子|スイーツ|甘い|研究|勉強|大学|実験|デート|会いたい|お出かけ|一緒に/);if(match){const w=match[0];context[x.id]=/水族館|クラゲ|海/.test(w)?'aquarium':/猫|ねこ|にゃん/.test(w)?'cat':/ケーキ|お菓子|スイーツ|甘い/.test(w)?'sweets':/研究|勉強|大学|実験/.test(w)?'study':'date';}arr.push({role:'user',text:message},{role:'character',text:reply});state.daily.count++;state.affinity[x.id]=Math.min(100,affinity()+1);if(arr.length===2)addMemory(x.name+'と初めて会話した');save();render()}
function dbOpen(){return new Promise((resolve,reject)=>{if(!window.indexedDB)return reject(Error('IndexedDB非対応'));const req=indexedDB.open('yatto-aetane-images-v70',1);req.onupgradeneeded=()=>req.result.createObjectStore('images');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function storeImage(id,blob){const db=await dbOpen();await new Promise((resolve,reject)=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').put(blob,id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});db.close()}
async function restoreImages(){try{const db=await dbOpen();for(const x of chars){const blob=await new Promise((resolve,reject)=>{const req=db.transaction('images','readonly').objectStore('images').get(x.id);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)});if(blob){const digest=await hashFile(blob);if(digest===expectedHashes[x.id])imageUrls[x.id]=URL.createObjectURL(blob)}}db.close();render()}catch(e){console.warn('画像復元不可:',e.message)}}
async function hashFile(blob){if(!crypto?.subtle)throw Error('この環境ではSHA-256検証が使えません。HTTPSまたはlocalhostで開いてください');const buffer=await blob.arrayBuffer();const digest=await crypto.subtle.digest('SHA-256',buffer);return Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('')}
app.addEventListener('change',async e=>{const id=e.target.dataset.imageId;if(!id)return;const file=e.target.files?.[0];if(!file)return;const status=document.getElementById('image-status');try{if(!file.type.startsWith('image/'))throw Error('画像ファイルを選択してください');if(file.size>8*1024*1024)throw Error('8MB以下の画像を選択してください');const hash=await hashFile(file);if(hash!==expectedHashes[id])throw Error('承認済み画像のSHA-256と一致しません。登録しませんでした');await storeImage(id,file);if(imageUrls[id])URL.revokeObjectURL(imageUrls[id]);imageUrls[id]=URL.createObjectURL(file);status.textContent='画像を検証して保存しました';}catch(err){status.textContent='画像の読み込み失敗：'+err.message}});
app.addEventListener('click',e=>{let el=e.target.closest('[data-go],[data-select],[data-choice],[data-action]');if(!el)return;if(el.dataset.go)go(el.dataset.go);if(el.dataset.select)start(el.dataset.select);if(el.dataset.choice)storyChoice(el.dataset.choice);if(el.dataset.action==='approve'){let name=document.getElementById('username').value.trim();if(!name||!document.getElementById('consent').checked){alert('名前と同意の確認が必要です');return}state.name=name;state.consent=true;state.approved=true;save();go('characters')}if(el.dataset.action==='cancel-date'){if(state.datePlans)delete state.datePlans[state.selected];save();render()}if(el.dataset.action==='clear-chat'&&confirm('会話履歴を削除しますか？')){state.messages={};state.conversationContext={};state.personalMemory={};save();render()}if(el.dataset.action==='reset'&&confirm('すべての体験データを削除します。よろしいですか？')){localStorage.removeItem(KEY);state=defaults();dbOpen().then(db=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').clear();tx.oncomplete=()=>db.close()}).catch(()=>{});Object.values(imageUrls).forEach(url=>URL.revokeObjectURL(url));Object.keys(imageUrls).forEach(id=>delete imageUrls[id]);go('home')}if(el.dataset.action==='export'){let blob=new Blob([JSON.stringify({format:'yatto-aetane-backup',version:'11.1',exportedAt:new Date().toISOString(),data:state},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='yatto-aetane-v111-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}});
app.addEventListener('change',async e=>{
 if(!e.target.matches('[data-import-backup]'))return;
 const status=document.getElementById('backup-status');try{
  const file=e.target.files?.[0];if(!file)return;if(file.size>2*1024*1024)throw Error('2MB以下のバックアップを選択してください');
  const imported=JSON.parse(await file.text());const data=imported?.format==='yatto-aetane-backup' ? imported.data : imported;if(!data||typeof data!=='object'||Array.isArray(data)||data.approved!==true||typeof data.name!=='string'||data.name.length>30||!data.consent||!chars.some(x=>x.id===data.selected)||!data.messages||typeof data.messages!=='object'||!Array.isArray(data.memories))throw Error('対応する体験版データではありません');
  if(!confirm('現在の保存データをバックアップで置き換えますか？（本日の送信回数は減りません）'))return;
  const clean={...defaults(),...data};clean.name=data.name.slice(0,30);clean.memories=data.memories.slice(0,20).filter(m=>m&&typeof m.text==='string'&&m.text.length<1000&&chars.some(x=>x.id===m.char));
  clean.messages=Object.fromEntries(chars.map(x=>[x.id,Array.isArray(data.messages[x.id])?data.messages[x.id].filter(m=>m&&['user','character'].includes(m.role)&&typeof m.text==='string').slice(-300).map(m=>({role:m.role,text:m.text.slice(0,300)})):[]]));
  clean.datePlans=Object.fromEntries(chars.flatMap(x=>{const v=data.datePlans?.[x.id];return v&&typeof v==='object'&&typeof v.place==='string'&&v.place.length<=100&&['accepted','proposed'].includes(v.status)?[[x.id,{place:v.place,status:v.status}]]:[]}));
  clean.stage=Object.fromEntries(chars.map(x=>[x.id,Math.min(5,Math.max(0,Number(data.stage?.[x.id])||0))]));
  clean.affinity=Object.fromEntries(chars.map(x=>[x.id,Math.min(100,Math.max(0,Number(data.affinity?.[x.id])||0))]));
  clean.personalMemory=Object.fromEntries(chars.map(x=>[x.id,Array.isArray(data.personalMemory?.[x.id])?data.personalMemory[x.id].filter(v=>v&&typeof v.value==='string'&&v.value.length<=200&&typeof v.type==='string').slice(-30).map(v=>({type:v.type.slice(0,30),value:v.value})):[]]));
  clean.conversationContext=Object.fromEntries(chars.map(x=>[x.id,['aquarium','cat','sweets','study','date'].includes(data.conversationContext?.[x.id])?data.conversationContext[x.id]:'']));
  const currentCount=state.daily?.day===today()?Math.min(30,Math.max(0,Number(state.daily.count)||0)):0;
  const importedCount=data.daily?.day===today()?Math.min(30,Math.max(0,Number(data.daily.count)||0)):0;
  clean.daily={day:today(),count:Math.max(currentCount,importedCount)};
  state=clean;save();render();if(status)status.textContent='バックアップを復元しました。';
 }catch(err){if(status)status.textContent='読み込み失敗：'+err.message;}
});
app.addEventListener('submit',e=>{if(e.target.id==='chat-form'){e.preventDefault();let val=new FormData(e.target).get('message').trim();if(val)send(val)}});render();
window.__demoTest={getState:()=>state,select:start,choice:storyChoice,send,go,demoReply,dateRecall,nextDateSuggestion,suggestionReply,datePlanReply};
restoreImages();})();
